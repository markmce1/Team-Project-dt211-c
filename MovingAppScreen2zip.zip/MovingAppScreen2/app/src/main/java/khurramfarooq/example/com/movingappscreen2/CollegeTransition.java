package khurramfarooq.example.com.movingappscreen2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.content.Intent;

public class CollegeTransition extends AppCompatActivity {

    ImageButton imageButton_MovingCollege;
    ImageButton Maps;
    ImageButton Photodiary;
    ImageButton Phonebook;
    ImageButton Backbutton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_college_transition);

        imageButton_MovingCollege = (ImageButton) findViewById(R.id.imageButton_MovingCollege);
        imageButton_MovingCollege.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(CollegeTransition.this, MovingCollege.class);
                startActivity(intent);
            }
        });

        Maps = (ImageButton) findViewById(R.id.Maps);
        Maps.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(CollegeTransition.this, Maps.class);
                startActivity(intent);
            }
        });

        Photodiary = (ImageButton) findViewById(R.id.Photodiary);
        Photodiary.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(CollegeTransition.this, Photodiary.class);
                startActivity(intent);
            }
        });

        Phonebook = (ImageButton) findViewById(R.id.Phonebook);
        Phonebook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(CollegeTransition.this, Phonebook.class);
                startActivity(intent);
            }
        });

        Backbutton = (ImageButton) findViewById(R.id.Backbutton);
        Backbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(CollegeTransition.this, SelectTransition.class);
                startActivity(intent);
            }
        });
    }
}
