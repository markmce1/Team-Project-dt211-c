package khurramfarooq.example.com.movingappscreen2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.content.Intent;

public class HousingTransition extends AppCompatActivity {

    ImageButton imageButton_MovingHouse;
    ImageButton Maps;
    ImageButton Photodiary;
    ImageButton Phonebook;
    ImageButton Backbutton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_housing_transition);

        imageButton_MovingHouse = (ImageButton) findViewById(R.id.imageButton_MovingHouse);
        imageButton_MovingHouse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Toast.makeText(MainActivity.this, "works!", Toast.LENGTH_LONG.show());
                //New intent to ensure user ends up, at home page of app after log in is successful
                Intent intent = new Intent(HousingTransition.this, MovingHouse.class);
                startActivity(intent);
            }
        });

        Maps = (ImageButton) findViewById(R.id.Maps);
        Maps.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HousingTransition.this, Maps.class);
                startActivity(intent);
            }
        });

        Photodiary = (ImageButton) findViewById(R.id.Photodiary);
        Photodiary.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HousingTransition.this, Photodiary.class);
                startActivity(intent);
            }
        });

        Phonebook = (ImageButton) findViewById(R.id.Phonebook);
        Phonebook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HousingTransition.this, Phonebook.class);
                startActivity(intent);
            }
        });

        Backbutton = (ImageButton) findViewById(R.id.Backbutton);
        Backbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HousingTransition.this, SelectTransition.class);
                startActivity(intent);
            }
        });
    }
}
