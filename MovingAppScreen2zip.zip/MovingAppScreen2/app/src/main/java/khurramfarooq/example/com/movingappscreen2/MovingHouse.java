package khurramfarooq.example.com.movingappscreen2;

import android.content.Intent;
import android.net.Uri;
import android.net.UrlQuerySanitizer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageButton;

import java.net.URL;

public class MovingHouse extends AppCompatActivity {

    ImageButton Backbutton;

    ImageButton check;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_moving_house);

        Backbutton = (ImageButton) findViewById(R.id.Backbutton);
        Backbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MovingHouse.this, HousingTransition.class);
                startActivity(intent);
            }
        });

        check = (ImageButton) findViewById(R.id.check);
        check.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MovingHouse.this, HousingChecklist.class);
                startActivity(intent);
            }
        });
    }

    public void open(View view){
       Intent browserIntent= new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.myhome.ie/"));
       startActivity(browserIntent);
    }

}
