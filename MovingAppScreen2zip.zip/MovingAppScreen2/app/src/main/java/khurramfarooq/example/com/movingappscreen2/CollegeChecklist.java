package khurramfarooq.example.com.movingappscreen2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

public class CollegeChecklist extends AppCompatActivity {

    ImageButton Backbutton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_college_checklist);

        Backbutton = (ImageButton) findViewById(R.id.Backbutton);
        Backbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(CollegeChecklist.this, MovingCollege.class);
                startActivity(intent);
            }
        });

    }
}
