package khurramfarooq.example.com.movingappscreen2;

import android.speech.tts.TextToSpeech;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.content.Intent;
import android.widget.TextView;

import java.util.Locale;

public class SelectTransition extends AppCompatActivity {

    private TextToSpeech mTTS;
    private TextView mTextView;
    private Button mButtonSpeak;
    ImageButton imageButton_movinghouse;
    ImageButton imageButton_movingcollege;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_transition);

        //Button  = (Button) findViewById(R.id.help3);
        mButtonSpeak = findViewById(R.id.help3);

        mTTS = new TextToSpeech(SelectTransition.this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if(status == TextToSpeech.SUCCESS)
                {
                    int result = mTTS.setLanguage(Locale.ENGLISH);

                    if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED)
                    {
                        Log.e("TTS", "Initialization failed");
                    }
                }
            }
        });


        imageButton_movinghouse = (ImageButton) findViewById(R.id.imageButton_movinghouse);
        imageButton_movinghouse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SelectTransition.this, HousingTransition.class);
                startActivity(intent);
            }
        });

        mTextView = findViewById(R.id.select_page_description);
        mButtonSpeak.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                speak();
            }
        });

        imageButton_movingcollege = (ImageButton) findViewById(R.id.imageButton_movingcollege);
        imageButton_movingcollege.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SelectTransition.this, CollegeTransition.class);
                startActivity(intent);
            }
        });
    }

    private void speak()
    {
        String text = mTextView.getText().toString();
        mTTS.setPitch(100/50);
        mTTS.setSpeechRate(100/50);

        mTTS.speak(text, TextToSpeech.QUEUE_FLUSH, null);
    }

    @Override
    protected  void onDestroy()
    {
        if(mTTS != null)
        {
            mTTS.stop();
            mTTS.shutdown();
        }
        super.onDestroy();
    }
}
